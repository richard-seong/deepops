#-*- coding: utf-8 -*-
import sys
import os
import argparse
import re
import subprocess
from datetime import datetime
import hashlib
import random
from dotenv import load_dotenv
load_dotenv()

__CODING_TYPE__     = "utf-8"
__LOG_TYPE_LIST__   = ["file","stdout"]
__LOG_TYPE__        = __LOG_TYPE_LIST__[0]
__NEWLINE_CHAR__                = "\n"
__NEWLINE_ALTERNATIVE_CHAR__    = "{n}"
def getExceptPrint(msg):return "{} Exception: {}".format(sys._getframe(1).f_code.co_name, msg)
def getDateTime():      return datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
__RESULT__          =[]
__TEST_ID__         =""
__TEST_COUNT__      =0
def testSubIdCountImcrement():
    global __TEST_COUNT__
    __TEST_COUNT__  +=1
    return
__SYS_FILE_MODE__   =""
__SYS_FILE_NAME__   =""
__HOST_NAME__       =""

__SUBPROCESS_LOG_ON__   = True

def getResult():
    if all(item is True for item in __RESULT__):
        return True
    else:
        return False

__IP_VERIFICATION__                 = re.compile(r"^(\d\d?\d?\.\d\d?\d?\.\d\d?\d?\.\d\d?\d?)$")

__NETWORK_INTERFACE_PREFIX_LIST__   = ["all","bond","ibs","eth","net"]
__NETWORK_INTERFACE_PREFIX__        = __NETWORK_INTERFACE_PREFIX_LIST__[0]  # 0:all, 1: host Network (Ethernet), 2: host Network (Infiniband), 3: POD Network (Ethernet), 4: POD Network (Infiniband)
def __NETWORK_INTERFACE_NAME__(prefix): return re.compile("({}[0-9]*)\:[\s]+flags".format(prefix))
__NETWORK_INTERFACE_IP_CHECK__      = re.compile(r"inet[\s]+([0-9]*\.[0-9]*\.[0-9]*\.[0-9]*)[\s]+netmask")
__FILE_NAME__           = r"/var/log/diag-infra/{}.log.{}".format(sys.argv[0].split("/")[-1].split(".py")[0], datetime.now().strftime("%Y%m%d"))
__INVENTORY_FILE__      = "inventory"
def __SYS_FILENAME__(): return re.compile(r"([func|perf]+)_([\_a-z0-9]*).py$").findall(sys.argv[0])
def __HOST_NAME__(x):   return re.compile(r"\[{}\]?".format(x))
__HOST_NAME_RANGE__ = re.compile(r"([a-z0-9\-]*)\[([0-9]*)\:([0-9]*)\]")
__PING_INFO__           = re.compile(r"PING [0-9a-z\.]* \(([0-9]*.[0-9]*.[0-9]*.[0-9]*)\)?")     #PING 10.91.9.200 (10.91.9.200) 56(84) bytes of data. / #PING localhost (127.0.0.1) 56(84) bytes of data.
__PING_REPLY__          = re.compile(r"[0-9]* bytes from [0-9a-z]* \(([0-9]*.[0-9]*.[0-9]*.[0-9]*)\)\: icmp_seq=([0-9]*) ttl=([0-9]*) time=([0-9\.]*)?")    #64 bytes from localhost (127.0.0.1): icmp_seq=1 ttl=64 time=0.045 ms
__PING_RESULT__         = re.compile(r"([0-9]*) packets transmitted, ([0-9]*) received, ([0-9]*)\% packet loss, time ([0-9]*)?")    #10 packets transmitted, 10 received, 0% packet loss, time 9217ms
__PING_ERROR__          = re.compile(r"ping\: [\–a-zA-Z]*\: Temporary failure in name resolution")   #ping: –I: Temporary failure in name resolution
#ARGUMENT __TARGET_GROUP
__TARGET_GROUP_HOST__   = re.compile(r"^([\-0-9a-z]*)\[([0-9]+)\:([0-9]+)\]")
__TARGET_GROUP_IP__     = re.compile(r"^([0-9]*.[0-9]*.[0-9]*.[0-9]?)\[([0-9]+)\:([0-9]+)\]")
#FILESYSTEM
__FILESYSTEM_MOUNTON__  = re.compile(r"^[\/\-\_a-zA-Z0-9]*[\s]+[0-9A-Z\.]*[\s]+[0-9A-Z\.]*[\s]+[0-9A-Z\.]*[\s]+[0-9A-Z\.\%]*[\s]+(\/data)$")
#GDS
__GDS_CHECK_CMD__       = r'''/usr/local/cuda-11.6/gds/tools/gdscheck -p | grep "WekaFS\|rdma"'''
__GDS_CHECK_WEKA_FS__   = re.compile(r"WekaFS[\s]+\:[\s]+Supported")
__GDS_CHECK_RDMA__      = re.compile(r"RDMA[\s]+\:[\s]+Supported")
__GDS_BENCHMARK_CMD__   = r"""/usr/local/cuda-11.6/gds/tools/gdsio -x 0 -T 60 -s 1G -i 4096k -I 0 -D /data/gdsio -d 0 -w 32 -n 3 -D /data/gdsio -d 1 -w 32 -n 3 -D /data/gdsio -d 2 -w 32 -n 1 \ -D /data/gdsio -d 3 -w 32 -n 1 -D /data/gdsio -d 4 -w 32 -n 7 -D /data/gdsio -d 5 -w 32 -n 7 -D /data/gdsio -d 6 -w 32 -n 5 -D /data/gdsio -d 7 -w 32 -n 5"""
__GDS_THROUGHPUT__      = re.compile(r"IOSize\:[\s\+[0-9]*\([a-zA-z]*\)[\s]+Throughput\:[\s]+([\.0-9]*)[\s]+[a-zA-z]*\/sec\,")
__GDS_TRIALS_COUNT__    = int(os.environ.get("GDS_TRIALS_COUNT")) if os.environ.get("GDS_TRIALS_COUNT")!=None else 3
__GDS_CUTLINE_VALUE__   = int(os.environ.get("GDS_CUTLINE_VALUE")) if os.environ.get("GDS_CUTLINE_VALUE")!=None else 20
#NVIDIA_SIM
__NVIDIA_SIM_LISTUP__   = re.compile(r"\|[\s]*[0-9]*[\s]*[\.\-\_a-zA-z0-9\s]*[(On|Off)]+[\s]*\|")
__NVIDIA_SIM_FAILED__   = re.compile(r"NVIDIA-SMI has failed")
#NVCC
__NVCC_CHECK__          = re.compile(r"release[\s]+([\.0-9]*)\,[\s]+(V[\.0-9]*)")
#KUBECTL
__KUBECTL_CHECK__       = re.compile(r"not[\s]+found\,[\s]+did[\s]+you[\s]+mean\:")
#teleport
__TELEPORT_PARAM__      = re.compile(r"([a-z0-9]*)\-[a-z]*")
__TELEPORT_SRC_LIST__   = {"n3":"n3-port.spcinfra.cloud",
                           "n4":"n4-port.spcinfra.cloud",
                           "n6":"n6-port.spcinfra.cloud"}
def __CLUSTER_SUFFIX__(param):  return r"{}-cluster".format(param)
def __TELEPORT_CMD_1__(src):    return r"tsh login --proxy={}:443 --auth=local --user=sgcp {}".format(src,src)
def __TELEPORT_CMD_2__():       return r"export KUBECONFIG=${HOME?}/teleport-kubeconfig.yaml"
def __TELEPORT_CMD_3__(cluster):return r"tsh kube login {}".format(cluster)
def __TELEPORT_CMD_4__():       return r"kubectl get pods"
__KUBECTL_PODS_COLUMNS__= re.compile(r"NAME[\s]+READY[\s]+STATUS[\s]+RESTARTS[\s]+AGE")
__KUBECTL_PODS_NORMAL__ = re.compile(r"(No resources found in default namespace)")
#GDR
__GDR_SSH_FILE__        = r"/root/.ssh/authorized_keys"
__GDR_SSH_CMD__         = r"service ssh start"
__GDR_ENV_CMD_1__       = r"cd hpcx-v2.10-gcc-MLNX_OFED_LINUX-5-ubuntu20.04-cuda11-gdrcopy2-nccl2.11-x86_64"
__GDR_ENV_CMD_2__       = r"source hpcx-init.sh"
__GDR_ENV_CMD_3__       = r"hpcx_load"
__GDR_ENV_CMD_4__       = r"export PMIX_INSTALL_PREFIX=/hpcx-v2.10-gcc-MLNX_OFED_LINUX-5-ubuntu20.04-cuda11-gdrcopy2-n ccl2.11-x86_64/ompi"
def __GDR_MPIRUN_CMD__(ipList): return r"mpirun --allow-run-as-root -np 2 -v -H {} -x LD_LIBRARY_PATH -x CUDA_VISIBLE_DEVICES=0 -x UCX_RNDV_SCHEME=get_zcopy $HPCX_OSU_CUDA_DIR/osu_bw D D".format(",".join(ipList))
__GDR_LOG_COLUMNS__     = re.compile(r"Size Bandwidth \(MB\/s\)")
__GDR_LOG_DATA__        = re.compile(r"^[0-9]*[\s]+([\.0-9]*)$")
__GDR_CUTLINE_VALUE__   = int(os.environ.get("GDR_CUTLINE_VALUE")) if os.environ.get("GDR_CUTLINE_VALUE")!=None else 150
def __GDR_BANDWIDTH_CHECK__(mb):return (float(mb)*125)>=__GDR_CUTLINE_VALUE__
#harbor & proxy
def __HARBOR_CMD_1__(id,pw,image):  return r'''crictl pull --creds "{}:{}" {}'''.format(id,pw,image)
__HARBOR_PULL_MSG__     = re.compile(r"Image[\s]+is[\s]+up")
def __HARBOR_CMD_2__(image):return r'''nerdctl push {}'''.format(image)
def __HARBOR_CMD_3__(image):return r'''crictl images | grep {}'''.format(image)
#perf
def __POD_ETHENET_CMD__(type="s"):return r"iperf3 -{}".format(("s" if type=="s" else "c"))
__POD_ETHERNET_SERVER_MSG__         = re.compile(r"client[\s]+to[\s]+connect")
__POD_ETHERNET_CUTLINE_VALUE__      = int(os.environ.get("POD_ETHERNET_CUTLINE_VALUE")) if os.environ.get("POD_ETHERNET_CUTLINE_VALUE")!=None else 9
__POD_ETHERNET_PARSER__             = re.compile(r"\[[\s0-9]*\][\s]*[\-\.0-9]*[\s]*[a-z]*[\s]*[\.0-9]*[\s]*[a-zA-z]*[\s]*([\.0-9]*)[\s]*[a-zA-z]*\/sec[\s0-9]*[(sender|receiver)]")
__POD_INFINIBAND_CMD__              = r"ib_write_bw"
__POD_INFINIBAND_SERVER_CHECK_CMD__ = r"ps aux | grep -c ib_write_bw"
__POD_INFINIBAND_PARSER__           = re.compile(r"[0-9]*[\s]*[0-9]*[\s]*[0-9]*\.[0-9]*[\s]*([0-9]*\.[0-9]*)[\s]*[0-9]*\.[0-9]*[\s]*")
__POD_INFINIBAND_CUTLINE_VALUE__    = int(os.environ.get("POD_INFINIBAND_CUTLINE_VALUE")) if os.environ.get("POD_INFINIBAND_CUTLINE_VALUE")!=None else 19000
#diff resource
def __DIFF_RESOURCE_CMD__(bfile,ffile): return r"diff {} {}".format(bfile,ffile)

def setupParams():
    global __HOST_NAME__, __TEST_ID__, __SYS_FILE_MODE__, __SYS_FILE_NAME__, __TEST_COUNT__
    __TEST_COUNT__ = 0
    __TEST_ID__     = hashlib.sha1(str(getDateTime()).encode(__CODING_TYPE__)).hexdigest()[:8]
    [(__SYS_FILE_MODE__,__SYS_FILE_NAME__)] = __SYS_FILENAME__()
    __HOST_NAME__   = os.uname()[1]
    return

def subprocessLogOff():
    global __SUBPROCESS_LOG_ON__
    __SUBPROCESS_LOG_ON__ = False
    return

def subprocessOpen(command):
    try:
        testSubIdCountImcrement()
        popen = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
        (stdoutdata, stderrdata) = popen.communicate()
        stdout = stdoutdata.decode(__CODING_TYPE__)
        stderr = stderrdata.decode(__CODING_TYPE__)
        if stderr!="" and __SUBPROCESS_LOG_ON__:
            print(stderr)
        return stdout, stderr
    except Exception as e:
        logType(getMergeLog("total", False, getExceptPrint(e)))
        return None, None

def pingNetworkType(network_type, ip):
    if network_type!="":
        testForPing(r"\-I {}".format(network_type), ip)
    else:
        testForPing("", ip)
    return

def testForPing(mode_cmd, ip):
    try:
        line_start  = "########## ping test start ##########\n"
        line_end    = "########## ping test end ##########\n"
        str_command = "ping -c 10 {} {}".format(mode_cmd,ip)
        stdout, stderr  = subprocessOpen(str_command)

        info    = __PING_INFO__.findall(stdout)
        list    = __PING_REPLY__.findall(stdout)
        result  = __PING_RESULT__.findall(stdout)
        msg = ""
        global __RESULT__
        testSubIdCountImcrement()
        flag = True if result[0][2] == '0' else False
        __RESULT__.append(flag)
        logType(getMergeLog("sub", flag, stdout))
    except Exception as e:
        logType(getMergeLog("sub", False, getExceptPrint(e)))
    return

def getNetworkInterface(interface):
    list = []
    # if __NETWORK_INTERFACE_PREFIX__ == __NETWORK_INTERFACE_PREFIX_LIST__[0]:
    #     list.append("")
    #     return list
    try:
        stdout, stderr = subprocessOpen(r"ifconfig | grep {}".format(interface))
        for line in stdout.split("\n"):
            network_interface = __NETWORK_INTERFACE_NAME__(interface).findall(line)
            if len(network_interface)>0:
                list.append(network_interface[0])
    except Exception as e:
        print(getExceptPrint(e))
    return list

def logTypeSetup(logType):
    global __LOG_TYPE__
    __LOG_TYPE__= logType
    return

def isLogTypeFile():
    return True if (__LOG_TYPE__==__LOG_TYPE_LIST__[0]) else False

def getMergeLog(type, success=False, log=None, metric_value=None):
    strSuccess      = "INFO"
    strTotal        = "Completed"
    strMetricValue  = "1"
    if success is False:
        strSuccess      = "ERROR"
        strTotal        = "Error"
        strMetricValue  = "0"
    if metric_value is not None:
        strMetricValue  = metric_value
    #[Datetime] [Hostname] diag-infra: [ERROR|INFO] [Func|Perf] [TestCase] [TestID] [TestSubID] [Metric Values] [messages]
    #[Datetime] [Hostname] diag-infra: [ERROR|INFO] [Func|Perf] [TestCase] [TestID] [Completed|Error] [Metric Values]
    msg = ""
    try:
        default_msg = "{} {} diag-infra: {} {} {} {}".format(
            getDateTime(), __HOST_NAME__,
            strSuccess, __SYS_FILE_MODE__, __SYS_FILE_NAME__, __TEST_ID__)
        if type=="sub" and log==None:
            argumentErrorLog("log","")
        elif type=="total" and log==None:
            msg = default_msg+" {} {}\n".format(strTotal, strMetricValue)
        else:
            convertLog = log.replace(__NEWLINE_CHAR__, __NEWLINE_ALTERNATIVE_CHAR__)
            if type == "total" and log != None:
                msg = default_msg + " {} {} {}\n".format(strTotal, strMetricValue, convertLog)
            elif type=="sub" and log != None:
                msg = default_msg+" {} {} {}\n".format(__TEST_COUNT__, strMetricValue, convertLog)
            else:
                msg = getExceptPrint("type: Invalid argument: {}".format(type))
    except Exception as e:
        print(getExceptPrint(e))
    return msg

def failedLogMerge(msg):
    logType(getMergeLog("sub", False, msg))
    logType(getMergeLog("total", False))
    return

def logType(message):
    try:
        if isLogTypeFile():
            file = open(__FILE_NAME__, 'a+')
            file.write(message)
            file.close()
        else:
            print(message)
    except Exception as e:
        print(getExceptPrint(e))
    return

def listStr(values):
    return values.split(',')

def argumentLogTypeCheck(log):
    flag = False
    for check in __LOG_TYPE_LIST__:
        if check==log:
            flag = True
            logTypeSetup(log)
            break
    if not flag:
        argumentErrorLog("log",log)
    return flag

def argumentErrorLog(argumentName,msg):
    logType(getMergeLog("total", False, "error: argument --{}: Invalid argument: {}".format(argumentName,msg)))
    return

def argumentSetupForFileCommon():
    parser = argparse.ArgumentParser(description='Common TEST')
    parser.add_argument('--log', required=False, default=__LOG_TYPE__, help='/'.join(__LOG_TYPE_LIST__))

    args = parser.parse_args()

    if not argumentLogTypeCheck(args.log):
        return None
    else:
        return args

def argumentSetupForPing():
    parser = argparse.ArgumentParser(description='ping TEST')
    parser.add_argument('--log', required=False, default=__LOG_TYPE__, help='/'.join(__LOG_TYPE_LIST__))
    parser.add_argument('--target_group', required=True, type=listStr, help='input hostname or ip')
    parser.add_argument('--interface', required=True, help='interface')
    parser.add_argument('--sampling', required=False, type=int, default=0, help='sampling count')

    args = parser.parse_args()

    if not argumentLogTypeCheck(args.log):
        return None
    else:
        return args

def argumentSetupForTeleport():
    parser = argparse.ArgumentParser(description='teleport TEST')
    parser.add_argument('--log', required=False, default=__LOG_TYPE__, help='/'.join(__LOG_TYPE_LIST__))
    parser.add_argument('--params', required=True, help='jenkins parameter')

    args = parser.parse_args()

    if not argumentLogTypeCheck(args.log):
        return None
    else:
        return args

def argumentSetupForHarborOrProxy():
    parser = argparse.ArgumentParser(description='harbor & proxy TEST')
    parser.add_argument('--log', required=False, default=__LOG_TYPE__, help='/'.join(__LOG_TYPE_LIST__))
    parser.add_argument('--id', required=True, help='login ID')
    parser.add_argument('--pw', required=True, help='login Password')
    parser.add_argument('--image', required=True, help='image parameter')

    args = parser.parse_args()

    if not argumentLogTypeCheck(args.log):
        return None
    else:
        return args

def argumentSetupForGDS():
    parser = argparse.ArgumentParser(description='GDS TEST')
    parser.add_argument('--log', required=False, default=__LOG_TYPE__, help='/'.join(__LOG_TYPE_LIST__))
    parser.add_argument('--device_list', required=True, type=listStr, help='device name')
    parser.add_argument('--gpu_count', required=True, type=int, help='GPU count')

    args = parser.parse_args()

    if not argumentLogTypeCheck(args.log):
        return None
    else:
        return args

def argumentSetupForPODNetwork():
    parser = argparse.ArgumentParser(description='POD Network TEST')
    parser.add_argument('--log', required=False, default=__LOG_TYPE__, help='/'.join(__LOG_TYPE_LIST__))
    parser.add_argument('--type', required=True, default="server", help='server/client')
    parser.add_argument('--ip', required=False, default=None, help='server ip address')

    args = parser.parse_args()

    if not argumentLogTypeCheck(args.log):
        return None
    elif not (args.type == "server" or args.type == "client"):
        argumentErrorLog("type",args.type)
        return None
    elif (args.type == "client" and args.ip is None):
        argumentErrorLog("ip", args.ip)
        return None
    else:
        return args

def argumentSetupForTestGDR():
    parser = argparse.ArgumentParser(description='GDR TEST')
    parser.add_argument('--log', required=False, default=__LOG_TYPE__, help='/'.join(__LOG_TYPE_LIST__))
    parser.add_argument('--type', required=True, default="ssh", help='ssh/env')
    parser.add_argument('--key', required=False, default=None, help='ssh')

    args = parser.parse_args()

    if not argumentLogTypeCheck(args.log):
        return None
    elif not (args.type == "ssh" or args.type == "env"):
        argumentErrorLog("type", args.type)
        return None
    elif (args.type == "ssh" and args.key is None):
        argumentErrorLog("key", args.key)
        return None
    else:
        return args

def argumentSetupForBenchmarkGDR():
    parser = argparse.ArgumentParser(description='GDR Benchmark')
    parser.add_argument('--log', required=False, default=__LOG_TYPE__, help='/'.join(__LOG_TYPE_LIST__))
    parser.add_argument('--ip', required=True, default=None, help='ip')

    args = parser.parse_args()

    if not argumentLogTypeCheck(args.log):
        return None
    else:
        return args

def argumentSetupForDiffResource():
    parser = argparse.ArgumentParser(description='DiffResource TEST')
    parser.add_argument('--log', required=False, default=__LOG_TYPE__, help='/'.join(__LOG_TYPE_LIST__))
    parser.add_argument('--bfile', required=True, default=None, help='before file')
    parser.add_argument('--ffile', required=True, default=None, help='after file')

    args = parser.parse_args()

    if not argumentLogTypeCheck(args.log):
        return None
    else:
        return args

def getTargetGroupList(args_list):
    list=[]
    for item in args_list:
        host=__TARGET_GROUP_HOST__.findall(item)
        ip  =__TARGET_GROUP_IP__.findall(item)
        if len(host)>0:
            data = host[0]
            for idx in range(int(data[1]), int(data[2]) + 1):
                targetHost  = "{}{}".format(data[0],str(idx).zfill(data[1].__len__()))
                list.append(targetHost)
        elif len(ip)>0:
            data = ip[0]
            for idx in range(int(data[1]), int(data[2]) + 1):
                targetIp    = "{}{}".format(data[0],str(idx).zfill(data[1].__len__()))
                list.append(targetIp)
        else:
            list.append(item)
    return list

def setupForPing():
    try:
        setupParams()
        args = argumentSetupForPing()
        if args is not None:
            original_list = temp_list = getTargetGroupList(args.target_group)
            if args.sampling > 0:  # sampling 입력 한 경우
                count = args.sampling if (len(original_list) > args.sampling) else len(list)
                temp_list = random.sample(original_list, count)
            interface_list = getNetworkInterface(args.interface)
            if len(interface_list) == 0:
                logType(getMergeLog("total", False, "{}: network_interface type: {}: not found".format(__HOST_NAME__, args.interface)))
                return
            for idx1, interface in enumerate(interface_list):
                for idx2, targetIp in enumerate(temp_list):
                    pingNetworkType(interface, targetIp)

            logType(getMergeLog("total", getResult()))
    except Exception as e:
        logType(getMergeLog("total", False, getExceptPrint(e)))
    return

def setupForGDS():
    try:
        setupParams()
        args = argumentSetupForGDS()
        if args is not None:
            testForIfconfig(args.device_list)
            testForGDS()
            testForNvidiaSmi(args.gpu_count)
            testForNvcc()
            logType(getMergeLog("total", getResult()))
    except Exception as e:
        logType(getMergeLog("total", False, getExceptPrint(e)))
    return

def testForFilesystem():
    try:
        global __RESULT__
        setupParams()
        args = argumentSetupForFileCommon()
        if args is not None:
            str_command = r"df -h /data"
            stdout, stderr = subprocessOpen(str_command)
            if len(stderr)>0:
                logType(getMergeLog("sub", False, stderr))
                __RESULT__.append(False)
                return
            result = False
            for line in stdout.split("\n"):
                temp = __FILESYSTEM_MOUNTON__.findall(line)
                if len(temp)>0:
                    result = True
                    break
            __RESULT__.append(result)

            logType(getMergeLog("total", getResult(), stdout))
    except Exception as e:
        logType(getMergeLog("total", False, getExceptPrint(e)))
    return

def testForIfconfig(lists):
    global __RESULT__
    for item in lists:
        interface_flag  = False
        inet_ip_flag    = False
        try:
            str_command = r"ifconfig | grep {}".format(item)
            stdout, stderr = subprocessOpen(str_command)
            if len(stderr)>0:
                logType(getMergeLog("sub", False, stderr))
                __RESULT__.append(False)
                break
            for line in stdout.split("\n"):
                if interface_flag:
                    inet_ip = __NETWORK_INTERFACE_IP_CHECK__.findall(line)
                    if len(inet_ip)>0:
                        inet_ip_flag = True
                        break
                else:
                    network_interface = __NETWORK_INTERFACE_NAME__(item).findall(line)
                    if len(network_interface)>0:
                        interface_flag = True
            __RESULT__.append(inet_ip_flag)

            logType(getMergeLog("sub", inet_ip_flag, stdout))
        except Exception as e:
            logType(getMergeLog("sub", False, getExceptPrint(e)))
    return

def testForNvidiaSmi(count):
    try:
        global __RESULT__
        str_command = "nvidia-smi"
        stdout, stderr = subprocessOpen(str_command)
        if len(stderr)>0:
            logType(getMergeLog("sub", False, stderr))
            __RESULT__.append(False)
            return
        listup = []
        result = False
        for line in stdout.split("\n"):
            temp = __NVIDIA_SIM_LISTUP__.findall(line)
            if len(temp)>0:
                listup.append(line)
        if len(listup)==count:
            result = True
        __RESULT__.append(result)

        logType(getMergeLog("sub", result, stdout))
    except Exception as e:
        logType(getMergeLog("sub", False, getExceptPrint(e)))
    return

def testForNvcc():
    try:
        global __RESULT__
        str_command = "nvcc –v"
        stdout, stderr = subprocessOpen(str_command)
        if len(stderr) > 0:
            logType(getMergeLog("sub", False, stderr))
            __RESULT__.append(False)
            return
        nvcc = __NVCC_CHECK__.findall(stdout)
        result = len(nvcc)>0

        logType(getMergeLog("sub", result, stdout))
    except Exception as e:
        logType(getMergeLog("sub", False, getExceptPrint(e)))
    return

def testForTeleport():
    try:
        global __RESULT__
        setupParams()
        args = argumentSetupForTeleport()
        if args is not None:
            jenkins_param = args.params.replace("[","").replace("]","").split("|")
            paramList = __TELEPORT_PARAM__.findall(args.params)
            for param,cluster in zip(jenkins_param,paramList):
                setupParams()
                src = __TELEPORT_SRC_LIST__.get(cluster)
                clusterName = __CLUSTER_SUFFIX__(param)
                stdout, stderr  = subprocessOpen(__TELEPORT_CMD_1__(src))
                if len(stderr)>0:
                    logType(getMergeLog("total", False, __TELEPORT_CMD_1__(src)+" "+stderr))
                    continue
                stdout, stderr  = subprocessOpen(__TELEPORT_CMD_2__())
                if len(stderr)>0:
                    logType(getMergeLog("total", False, __TELEPORT_CMD_2__()+" "+stderr))
                    continue
                stdout, stderr  = subprocessOpen(__TELEPORT_CMD_3__(clusterName))
                if len(stderr)>0:
                    logType(getMergeLog("total", False, __TELEPORT_CMD_3__(clusterName)+" "+stderr))
                    continue
                stdout, stderr  = subprocessOpen(__TELEPORT_CMD_4__())
                if len(stderr)>0:
                    logType(getMergeLog("total", False, __TELEPORT_CMD_4__()+" "+stderr))
                    continue
                columns_flag    = __KUBECTL_PODS_COLUMNS__(stdout)
                normal_flag     = __KUBECTL_PODS_NORMAL__(stdout)
                msg = ""
                if len(columns_flag)>0 or len(normal_flag)>0:
                    msg = getMergeLog("total", True, stdout)
                else:
                    msg = getMergeLog("total", False, stdout)
                logType(msg)
    except Exception as e:
        logType(getMergeLog("total", False, getExceptPrint(e)))
    return

def testForHarboOrPorxy(type="harbor"):
    try:
        global __RESULT__
        setupParams()
        args = argumentSetupForHarborOrProxy()
        if args is not None:
            stdout, stderr = subprocessOpen(__HARBOR_CMD_1__(args.id, args.pw, args.image))
            if len(stderr) > 0:
                failedLogMerge(stderr)
                return
            pull_msg = __HARBOR_PULL_MSG__.findall(stdout)
            result = True if len(pull_msg)>0 else False
            __RESULT__.append(result)
            logType(getMergeLog("sub", result, stdout))
            if(type=="harbor"):
                stdout, stderr = subprocessOpen(__HARBOR_CMD_2__(args.image))
                if len(stderr) > 0:
                    failedLogMerge(stderr)
                    return
                result = True if len(stdout)>0 else False
                __RESULT__.append(result)
                logType(getMergeLog("sub", result, stdout))
            stdout, stderr = subprocessOpen(__HARBOR_CMD_3__(args.image))
            if len(stderr) > 0:
                failedLogMerge(stderr)
            else:
                result = True if len(stdout)>0 else False
                __RESULT__.append(result)
                logType(getMergeLog("sub", result, stdout))
                logType(getMergeLog("total", getResult()))
    except Exception as e:
        logType(getMergeLog("total", False, getExceptPrint(e)))
    return

def benchmarkTestForPODNetworkEthernet():
    try:
        global __RESULT__
        setupParams()
        subprocessLogOff()
        args = argumentSetupForPODNetwork()
        if args is not None:
            if args.type=="c":
                str_command = __POD_ETHENET_CMD__(args.type)
                stdout, stderr = subprocessOpen(str_command + " {}".format(args.ip))
                if len(stderr)>0:
                    failedLogMerge("client: " + stderr)
                    return
                for line in stdout.split("\n"):
                    temp = __POD_ETHERNET_PARSER__.findall(line)
                    if len(temp)>0:
                        value = float(temp[0])
                        __RESULT__.append(True)
                        logType(getMergeLog("sub", (value >= __POD_ETHERNET_CUTLINE_VALUE__), line, value))
                    else:
                        __RESULT__.append(False)
                        logType(getMergeLog("sub", False, line, 0))
                logType(getMergeLog("total", getResult()))
            else:
                str_command = __POD_ETHENET_CMD__(args.type)
                while True:
                    stdout, stderr = subprocessOpen(str_command)
                    if len(stderr)>0:
                        failedLogMerge("server: " + stderr)
                        continue
                    else:
                        logType(getMergeLog("total", True, stdout))
                        return
    except Exception as e:
        logType(getMergeLog("total", False, getExceptPrint(e)))
    return

def benchmarkTestForPODNetworkInfiniband():
    try:
        global __RESULT__
        setupParams()
        subprocessLogOff()
        args = argumentSetupForPODNetwork()
        if args is not None:
            if args.type=="client":
                str_command = __POD_INFINIBAND_CMD__+" {}".format(args.ip)
                repeat_count = 0
                while repeat_count<3:
                    while True:
                        stdout, stderr = subprocessOpen(str_command)
                        for line in stdout.split("\n"):
                            temp = __POD_INFINIBAND_PARSER__.findall(line)
                            if len(temp)>0:
                                value = float(temp[0])
                                flag  = (value >= __POD_INFINIBAND_CUTLINE_VALUE__)
                                __RESULT__.append(flag)
                                logType(getMergeLog("sub", flag, "client test: {}, ".format(repeat_count+1)+stdout, value))
                                break
                    repeat_count += 1
                logType(getMergeLog("total", getResult()))
            else:
                repeat_count = 0
                while repeat_count<10:
                    stdout, stderr = subprocessOpen(__POD_INFINIBAND_CMD__)
                    if len(stderr)>0:
                        failedLogMerge("server: " + stderr)
                        continue
                    while True:
                        stdout, stderr = subprocessOpen(__POD_INFINIBAND_SERVER_CHECK_CMD__)
                        if len(stderr)>0:
                            failedLogMerge("server: " + stderr)
                            continue
                        server_status = re.compile(r"[0-9]*").findall(stdout)
                        if len(server_status)>0 and server_status[0]=="1":  #server off
                            repeat_count += 1
                            break
                    logType(getMergeLog("sub", True, "retry count: ".format(repeat_count)))
                logType(getMergeLog("total", True))
    except Exception as e:
        logType(getMergeLog("total", False, getExceptPrint(e)))
    return

def testForGDS():
    try:
        global __RESULT__

        stdout, stderr = subprocessOpen(__GDS_CHECK_CMD__)
        if len(stderr) > 0:
            logType(getMergeLog("sub", False, stderr))
            __RESULT__.append(False)
            return
        weka = __GDS_CHECK_WEKA_FS__.findall(stdout)
        rdma = __GDS_CHECK_RDMA__.findall(stdout)
        result = len(weka)>0 and len(rdma)>0
        __RESULT__.append(result)

        logType(getMergeLog("sub", result, stdout))
    except Exception as e:
        logType(getMergeLog("sub", False, getExceptPrint(e)))
    return

def benchmarkTestForGDS():
    try:
        global __RESULT__
        setupParams()
        throughput_list = []
        args = argumentSetupForFileCommon()
        if args is not None:
            for idx in range(__GDS_TRIALS_COUNT__):
                stdout, stderr = subprocessOpen(__GDS_BENCHMARK_CMD__)
                if len(stderr)>0:
                    logType(getMergeLog("sub", False, stderr))
                    break
                throughput = __GDS_THROUGHPUT__.findall(stdout)
                flag = False
                if len(throughput)>0:
                    flag = True
                    throughput_list.append(float(throughput[0]))
                else:
                    throughput_list.append(float(0))
                logType(getMergeLog("sub", flag, stdout))
            avg = (sum(throughput_list)/len(throughput_list))
            logType(getMergeLog("total", (True if avg >= __GDS_CUTLINE_VALUE__ else False), None, avg))
    except Exception as e:
        logType(getMergeLog("total", False, getExceptPrint(e)))
    return

def testForGDR():
    try:
        global __RESULT__
        setupParams()
        args = argumentSetupForTestGDR()
        if args is not None:
            if args.type == "ssh":
                file = open(__GDR_SSH_FILE__, 'a+')
                file.write(r"\n"+args.key+r"\n")
                file.close()
                stdout, stderr = subprocessOpen(__GDR_SSH_CMD__)
                if len(stderr)>0:
                    logType(getMergeLog("total", False, __GDR_SSH_CMD__+": "+stderr))
            else:
                stdout, stderr = subprocessOpen(__GDR_ENV_CMD_1__)
                if len(stderr)>0:
                    failedLogMerge(__GDR_ENV_CMD_1__+": "+stderr)
                    return
                else:
                    logType(getMergeLog("sub", True, stdout))
                stdout, stderr = subprocessOpen(__GDR_ENV_CMD_2__)
                if len(stderr)>0:
                    failedLogMerge(__GDR_ENV_CMD_2__+": "+stderr)
                    return
                else:
                    logType(getMergeLog("sub", True, stdout))
                stdout, stderr = subprocessOpen(__GDR_ENV_CMD_3__)
                if len(stderr)>0:
                    failedLogMerge(__GDR_ENV_CMD_3__+": "+stderr)
                    return
                else:
                    logType(getMergeLog("sub", True, stdout))
                stdout, stderr = subprocessOpen(__GDR_ENV_CMD_4__)
                if len(stderr)>0:
                    failedLogMerge(__GDR_ENV_CMD_4__+": "+stderr)
                    return
                else:
                    logType(getMergeLog("sub", True, stdout))
                    logType(getMergeLog("total", True))
    except Exception as e:
        logType(getMergeLog("total", False, getExceptPrint(e)))
    return

def benchmarkTestForGDR():
    try:
        global __RESULT__
        setupParams()
        args = argumentSetupForBenchmarkGDR()
        if args is not None:
            count = len(args.ip)
            ipList = []
            if not count>0:
                argumentErrorLog("ip", args.ip)
                return
            else:
                for item in args.ip.split(","):
                    ip = __IP_VERIFICATION__.findall(item)
                    if len(ip)>0:
                        ipList.append(ip[0])
                if not (count==len(ipList)):
                    argumentErrorLog("ip", args.ip)
            stdout, stderr = subprocessOpen(__GDR_MPIRUN_CMD__(ipList))
            if len(stderr)>0:
                failedLogMerge(stderr)
                return
            bandwidth_list = []
            for line in stdout.split("\n"):
                temp = __GDR_LOG_DATA__.findall(line)
                if len(temp)>0:
                    bandwidth_list.append(temp[0])
            try:
                metric_value = float(bandwidth_list[-1])
                flag = __GDR_BANDWIDTH_CHECK__(metric_value)
                __RESULT__.append(flag)
                logType(getMergeLog("sub", flag, stdout, metric_value))
                logType(getMergeLog("total", getResult(), None, metric_value))
            except Exception as e:
                failedLogMerge(e)
    except Exception as e:
        logType(getMergeLog("total", False, getExceptPrint(e)))
    return

def testForDiffResource():
    try:
        global __RESULT__
        setupParams()
        args = argumentSetupForDiffResource()
        if args is not None:
            stdout, stderr = subprocessOpen(__DIFF_RESOURCE_CMD__(args.bfile,args.ffile))
            if len(stderr) > 0:
                failedLogMerge(stderr)
                return
            if not (stdout=="" or stdout==None):
                logType(getMergeLog("total", True, stdout))
            else:
                logType(getMergeLog("total", False, stdout))
    except Exception as e:
        logType(getMergeLog("total", False, getExceptPrint(e)))
    return

# Press the green button in the gutter to run the script.
# if __name__ == '__main__':

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
