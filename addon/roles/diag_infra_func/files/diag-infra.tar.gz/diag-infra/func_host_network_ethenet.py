#-*- coding: utf-8 -*-
import library.diag_func as dfunc

# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    # dfunc.__NETWORK_INTERFACE_PREFIX__ = "bond"
    dfunc.setupForPing()

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
