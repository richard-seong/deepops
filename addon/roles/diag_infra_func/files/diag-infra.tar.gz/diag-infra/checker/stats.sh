#!/usr/bin/bash

kubectl get all -A -ojson > t1.json
kubectl get pv -ojson > t2.json
kubectl get pvc -A -ojson > t3.json
kubectl get customresourcedefinitions.apiextensions.k8s.io -A -ojson > t4.json
kubectl get volumeattachments.storage.k8s.io -A -ojson > t5.json

cat t1.json t2.json t3.json t4.json t5.json > _$1
jq 'del(.items[].metadata)' _$1 | jq 'del(.items[].status)' | jq 'del(.items[] | select(.kind == "Revision"))' > $1

rm t1.json t2.json t3.json t4.json t5.json _$1
