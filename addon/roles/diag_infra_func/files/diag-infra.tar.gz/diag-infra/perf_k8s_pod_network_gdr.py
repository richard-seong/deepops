#-*- coding: utf-8 -*-
import library.diag_func as dfunc

# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    dfunc.benchmarkTestForGDR()

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
